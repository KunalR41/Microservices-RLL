package com.example.demo.respository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.domain.Admin;
//import com.example.demo.domain.User;




public interface AdminRepository extends JpaRepository<Admin, Integer> {
	
	public Admin findByEmailId(String emailId);
	public Admin findByEmailIdAndPassword(String emailId, String password);

}

