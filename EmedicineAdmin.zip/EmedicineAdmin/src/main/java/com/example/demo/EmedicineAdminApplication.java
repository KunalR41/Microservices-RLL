package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmedicineAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmedicineAdminApplication.class, args);
	}

}
