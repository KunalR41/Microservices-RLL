package com.example.demo.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Admin;
import com.example.demo.respository.AdminRepository;





@Service
public class AdminService {

	@Autowired
	private AdminRepository repo;
	
	public Admin saveAdmin(Admin admin){
		return repo.save(admin);
		}
	public Admin fetchAdminByEmailId(String email)
	{
		return repo.findByEmailId(email);
	}
	
	public Admin fetchAdminByEmailIdandPassword(String email, String password)
	{
		return repo.findByEmailIdAndPassword(email, password);
	}
}